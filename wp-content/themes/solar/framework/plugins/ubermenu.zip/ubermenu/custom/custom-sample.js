/* Copy or rename to custom.js and enable in the Control Panel to use */
jQuery( document ).ready( function($){

	//Your code here.  Don't nest ready() callbacks

});