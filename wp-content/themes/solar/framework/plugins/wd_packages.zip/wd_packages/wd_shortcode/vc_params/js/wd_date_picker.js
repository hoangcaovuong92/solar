/* Datepicker: wd_add_param_vc.php */
jQuery(document).ready(function($) {	
	jQuery( ".value_date_custom" ).datepicker({dateFormat: 'dd/mm/yyyy'});
});