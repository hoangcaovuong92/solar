/**
 * WD Products Color Filter
 *
 * @license commercial software
 * @copyright (c) 2013 Codespot Software JSC - WPDance.com. (http://www.wpdance.com)
 */


/*
(function($) {
	
	jQuery.noConflict();
	
	jQuery(function ($) {
	
		$('.wd-filter-by-color-list li.active').on('click', function(e){
			e.preventDefault();
		}); 

	});
	
})(jQuery);

*/