$( function() {
    $( ".startdate" ).datepicker();
    $( ".enddate" ).datepicker();
  } );